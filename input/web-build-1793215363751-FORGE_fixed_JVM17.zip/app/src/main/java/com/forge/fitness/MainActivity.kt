package com.forge.fitness

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0C1113)
private val Panel = Color(0xFF11191B)
private val Panel2 = Color(0xFF172124)
private val Mint = Color(0xFF42DDA5)
private val TextMain = Color(0xFFF0F4F3)
private val Muted = Color(0xFF93A19F)
private val Red = Color(0xFFEF6876)
private val Outline = Color(0xFF293639)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = ForgeDb(this)
        setContent { ForgeApp(db) }
    }
}

data class Workout(val id: Long, val date: String, val title: String, val duration: Int, val volume: Double)
data class ExerciseEntry(val id: Long, val workoutId: Long, val name: String, val sets: Int, val reps: Int, val weight: Double, val muscles: String, val completedSets: Int = 0)

class ForgeDb(context: Context) : SQLiteOpenHelper(context, "forge.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, title TEXT NOT NULL, duration INTEGER NOT NULL, volume REAL NOT NULL)")
        db.execSQL("CREATE TABLE exercises(id INTEGER PRIMARY KEY AUTOINCREMENT, workout_id INTEGER NOT NULL, name TEXT NOT NULL, sets INTEGER NOT NULL, reps INTEGER NOT NULL, weight REAL NOT NULL, muscles TEXT NOT NULL, completed_sets INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(workout_id) REFERENCES workouts(id))")
        db.execSQL("CREATE TABLE missed_dates(date TEXT PRIMARY KEY)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_exercises_workout_id ON exercises(workout_id)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE TABLE IF NOT EXISTS missed_dates(date TEXT PRIMARY KEY)")
        if (oldVersion < 3) db.execSQL("ALTER TABLE exercises ADD COLUMN completed_sets INTEGER NOT NULL DEFAULT 0")
        if (oldVersion < 4) db.execSQL("CREATE INDEX IF NOT EXISTS idx_exercises_workout_id ON exercises(workout_id)")
    }
    fun allWorkouts(): List<Workout> {
        val out = mutableListOf<Workout>()
        readableDatabase.rawQuery("SELECT id,date,title,duration,volume FROM workouts ORDER BY date DESC,id DESC", null).use { c ->
            while (c.moveToNext()) out += Workout(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getDouble(4))
        }
        return out
    }
    fun exercises(workoutId: Long? = null): List<ExerciseEntry> {
        val out = mutableListOf<ExerciseEntry>()
        val sql = if (workoutId == null) "SELECT id,workout_id,name,sets,reps,weight,muscles,completed_sets FROM exercises ORDER BY id DESC" else "SELECT id,workout_id,name,sets,reps,weight,muscles,completed_sets FROM exercises WHERE workout_id=? ORDER BY id"
        readableDatabase.rawQuery(sql, if (workoutId == null) null else arrayOf(workoutId.toString())).use { c ->
            while (c.moveToNext()) out += ExerciseEntry(c.getLong(0),c.getLong(1),c.getString(2),c.getInt(3),c.getInt(4),c.getDouble(5),c.getString(6),c.getInt(7))
        }
        return out
    }
    fun missedDates(): Set<String> {
        val out = mutableSetOf<String>()
        readableDatabase.rawQuery("SELECT date FROM missed_dates", null).use { c -> while (c.moveToNext()) out += c.getString(0) }
        return out
    }
    fun toggleMissed(date: String) {
        val db = writableDatabase
        if (missedDates().contains(date)) db.delete("missed_dates", "date=?", arrayOf(date))
        else if (allWorkouts().none { it.date == date }) db.insertWithOnConflict("missed_dates", null, ContentValues().apply { put("date", date) }, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun updateWorkout(id: Long, title: String, duration: Int) {
        writableDatabase.update("workouts", ContentValues().apply { put("title", title); put("duration", duration) }, "id=?", arrayOf(id.toString()))
    }
    fun setCompletedSets(exerciseId: Long, completed: Int) {
        writableDatabase.update("exercises", ContentValues().apply {
            put("completed_sets", completed.coerceAtLeast(0))
        }, "id=?", arrayOf(exerciseId.toString()))
        recalculateWorkoutVolume(exerciseId)
    }
    fun updateExercise(id: Long, name: String, sets: Int, reps: Int, weight: Double, muscles: String) {
        writableDatabase.update("exercises", ContentValues().apply {
            put("name", name); put("sets", sets.coerceAtLeast(1)); put("reps", reps.coerceAtLeast(1))
            put("weight", weight.coerceAtLeast(0.0)); put("muscles", muscles)
            put("completed_sets", 0)
        }, "id=?", arrayOf(id.toString()))
        recalculateWorkoutVolume(id)
    }
    fun deleteExercise(id: Long) {
        val row = readableDatabase.rawQuery("SELECT workout_id FROM exercises WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
        writableDatabase.delete("exercises", "id=?", arrayOf(id.toString()))
        if (row != null) recalculateWorkoutVolumeForWorkout(row)
    }
    private fun recalculateWorkoutVolume(id: Long) {
        val workoutId = readableDatabase.rawQuery("SELECT workout_id FROM exercises WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
        if (workoutId != null) recalculateWorkoutVolumeForWorkout(workoutId)
    }
    private fun recalculateWorkoutVolumeForWorkout(workoutId: Long) {
        val volume = readableDatabase.rawQuery("SELECT COALESCE(SUM(completed_sets * reps * weight),0) FROM exercises WHERE workout_id=?", arrayOf(workoutId.toString())).use { c -> if (c.moveToFirst()) c.getDouble(0) else 0.0 }
        writableDatabase.update("workouts", ContentValues().apply { put("volume", volume) }, "id=?", arrayOf(workoutId.toString()))
    }
    fun deleteWorkout(id: Long) {
        writableDatabase.beginTransaction()
        try { writableDatabase.delete("exercises", "workout_id=?", arrayOf(id.toString())); writableDatabase.delete("workouts", "id=?", arrayOf(id.toString())); writableDatabase.setTransactionSuccessful() }
        finally { writableDatabase.endTransaction() }
    }
    fun saveWorkout(title: String, duration: Int, entries: List<ExerciseEntry>): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val volume = entries.sumOf { it.completedSets.coerceIn(0, it.sets) * it.reps * it.weight }
            val w = ContentValues().apply { put("date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())); put("title", title); put("duration", duration); put("volume", volume) }
            val id = db.insertOrThrow("workouts", null, w)
            entries.forEach { e ->
                val cv = ContentValues().apply { put("workout_id", id); put("name", e.name); put("sets", e.sets); put("reps", e.reps); put("weight", e.weight); put("muscles", e.muscles); put("completed_sets", e.completedSets) }
                db.insertOrThrow("exercises", null, cv)
            }
            db.delete("missed_dates", "date=?", arrayOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())))
            db.setTransactionSuccessful(); return id
        } finally { db.endTransaction() }
    }
    fun exportJson(): String {
        val root = JSONObject().put("app", "FORGE").put("formatVersion", 1)
        val ws = JSONArray()
        allWorkouts().forEach { w ->
            val jo = JSONObject().put("date", w.date).put("title", w.title).put("duration", w.duration).put("volume", w.volume)
            val es = JSONArray()
            exercises(w.id).forEach { e -> es.put(JSONObject().put("name",e.name).put("sets",e.sets).put("reps",e.reps).put("weight",e.weight).put("muscles",e.muscles).put("completedSets",e.completedSets)) }
            jo.put("exercises", es); ws.put(jo)
        }
        root.put("workouts", ws).put("missedDates", JSONArray(missedDates().toList()))
        return root.toString(2)
    }
    fun importJson(json: String): Int {
        val root = JSONObject(json)
        require(root.optString("app") == "FORGE") { "Это не файл резервной копии FORGE" }
        require(root.optInt("formatVersion", 0) in 1..1) { "Версия резервной копии не поддерживается" }
        val ws = root.optJSONArray("workouts") ?: JSONArray()
        require(ws.length() <= 10000) { "В резервной копии слишком много тренировок" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("exercises", null, null); db.delete("workouts", null, null); db.delete("missed_dates", null, null)
            for (i in 0 until ws.length()) {
                val w = ws.getJSONObject(i)
                val date = w.optString("date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
                require(Regex("\\d{4}-\\d{2}-\\d{2}").matches(date)) { "Некорректная дата в резервной копии" }
                val title = w.optString("title", "Тренировка").take(80)
                val es = w.optJSONArray("exercises") ?: JSONArray()
                require(es.length() <= 300) { "В одной тренировке слишком много упражнений" }
                var volume = 0.0
                for (j in 0 until es.length()) { val e=es.getJSONObject(j); volume += e.optInt("completedSets",0).coerceAtLeast(0).coerceAtMost(e.optInt("sets",1)) * e.optInt("reps",1) * e.optDouble("weight",0.0) }
                val cv=ContentValues().apply { put("date",date); put("title",title); put("duration",w.optInt("duration",45).coerceIn(1, 600)); put("volume",volume) }
                val id=db.insertOrThrow("workouts",null,cv)
                for (j in 0 until es.length()) { val e=es.getJSONObject(j); db.insertOrThrow("exercises",null,ContentValues().apply { put("workout_id",id); put("name",e.optString("name","Упражнение").take(100)); put("sets",e.optInt("sets",1).coerceIn(1, 50)); put("reps",e.optInt("reps",1).coerceIn(1, 1000)); put("weight",e.optDouble("weight",0.0).coerceIn(0.0, 1000.0)); put("muscles",e.optString("muscles","Спина,Плечи").take(300)); put("completed_sets",e.optInt("completedSets",0).coerceIn(0,e.optInt("sets",1).coerceIn(1,50))) }) }
            }
            val missed = root.optJSONArray("missedDates") ?: JSONArray()
            for (i in 0 until missed.length()) db.insertWithOnConflict("missed_dates",null,ContentValues().apply { put("date",missed.optString(i)) },SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return ws.length()
    }
}
private val muscleNames = listOf("Грудь", "Спина", "Широчайшие", "Плечи", "Бицепс", "Трицепс", "Предплечья", "Пресс", "Косые мышцы", "Ягодицы", "Квадрицепсы", "Бицепс бедра", "Икры")

private data class ExercisePreset(val name: String, val muscles: String, val sets: Int = 3, val reps: Int = 10, val weight: Double = 0.0)
private val exerciseLibrary = listOf(
    ExercisePreset("Отжимания", "Грудь,Трицепс,Плечи", 3, 10),
    ExercisePreset("Жим гантелей лёжа", "Грудь,Трицепс,Плечи", 3, 10),
    ExercisePreset("Жим гантелей стоя", "Плечи,Трицепс", 3, 10),
    ExercisePreset("Разведения гантелей", "Плечи", 3, 12),
    ExercisePreset("Подтягивания", "Спина,Широчайшие,Бицепс", 3, 6),
    ExercisePreset("Тяга гантели в наклоне", "Спина,Широчайшие,Бицепс", 3, 10),
    ExercisePreset("Тяга гантелей к поясу", "Спина,Широчайшие,Бицепс", 3, 10),
    ExercisePreset("Сгибание рук на бицепс", "Бицепс,Предплечья", 3, 10),
    ExercisePreset("Французский жим", "Трицепс", 3, 10),
    ExercisePreset("Приседания", "Квадрицепсы,Ягодицы,Бицепс бедра", 3, 12),
    ExercisePreset("Болгарские выпады", "Квадрицепсы,Ягодицы", 3, 8),
    ExercisePreset("Румынская тяга с гантелями", "Ягодицы,Бицепс бедра,Спина", 3, 10),
    ExercisePreset("Подъёмы на носки", "Икры", 3, 15),
    ExercisePreset("Планка", "Пресс,Косые мышцы", 3, 30),
    ExercisePreset("Скручивания", "Пресс", 3, 12),
    ExercisePreset("Ягодичный мост", "Ягодицы,Бицепс бедра", 3, 12),
    ExercisePreset("Обратные отжимания", "Трицепс,Грудь", 3, 8),
    ExercisePreset("Подъёмы коленей", "Пресс", 3, 12)
)
private val workoutTemplates = mapOf(
    "Всё тело" to listOf("Приседания", "Отжимания", "Подтягивания", "Румынская тяга с гантелями", "Планка"),
    "Верх тела" to listOf("Отжимания", "Подтягивания", "Жим гантелей стоя", "Сгибание рук на бицепс", "Французский жим"),
    "Спина и бицепс" to listOf("Подтягивания", "Тяга гантели в наклоне", "Сгибание рук на бицепс", "Планка"),
    "Ноги и корпус" to listOf("Приседания", "Болгарские выпады", "Румынская тяга с гантелями", "Подъёмы на носки", "Планка")
)
private fun musclesFor(name: String): String {
    val n = name.lowercase(Locale.ROOT)
    return when {
        "жим" in n || "отжим" in n || "груд" in n -> "Грудь,Трицепс,Плечи"
        "подтяг" in n || "тяга" in n || "спин" in n -> "Спина,Широчайшие,Бицепс"
        "присед" in n || "выпад" in n || "ног" in n -> "Квадрицепсы,Ягодицы,Бицепс бедра"
        "плеч" in n || "развед" in n -> "Плечи"
        "бицепс" in n -> "Бицепс,Предплечья"
        "трицепс" in n -> "Трицепс"
        "пресс" in n -> "Пресс,Косые мышцы"
        else -> "Спина,Плечи"
    }
}

@Composable
fun ForgeApp(db: ForgeDb) {
    var page by remember { mutableStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    var showWorkout by remember { mutableStateOf(false) }
    var showCoach by remember { mutableStateOf(false) }
    var pendingPlan by remember { mutableStateOf<Pair<String, List<String>>?>(null) }
    var pendingImport by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try { context.contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) }; Toast.makeText(context, "Резервная копия сохранена", Toast.LENGTH_SHORT).show() } catch (e: Exception) { Toast.makeText(context, "Не удалось сохранить файл: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            pendingImport = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Не удалось прочитать файл")
        } catch (e: Exception) { Toast.makeText(context, "Ошибка чтения: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    val workouts = remember(refresh) { db.allWorkouts() }
    val entries = remember(refresh) { db.exercises() }
    val today = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint, onPrimary = Color(0xFF062319), background = Bg, surface = Panel,
        onSurface = TextMain, onBackground = TextMain, secondary = Mint
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B1012), contentColor = Muted) {
                val items = listOf("Главная", "Календарь", "Дневник", "Мышцы", "Статистика", "Профиль")
                val icons = listOf(Icons.Default.Home, Icons.Default.CalendarMonth, Icons.Default.MenuBook, Icons.Default.FitnessCenter, Icons.Default.ShowChart, Icons.Default.Person)
                items.forEachIndexed { i, label ->
                    NavigationBarItem(selected = page == i, onClick = { page = i },
                        icon = { Icon(icons[i], label) }, label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint,
                            indicatorColor = Color(0xFF18362D), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            AnimatedContent(targetState = page, transitionSpec = {
                androidx.compose.animation.fadeIn(tween(180)) togetherWith androidx.compose.animation.fadeOut(tween(120))
            }, label = "section", modifier = Modifier.padding(padding)) { current ->
                when (current) {
                    0 -> HomePage(today, workouts, entries, onStart = { showWorkout = true }, onNavigate = { page = it })
                    1 -> CalendarPage(workouts, db.missedDates(), onToggleMissed = { db.toggleMissed(it); refresh++ })
                    2 -> DiaryPage(workouts, entries, onStart = { showWorkout = true }, onDelete = { db.deleteWorkout(it); refresh++ }, onUpdate = { id, title, duration -> db.updateWorkout(id, title, duration); refresh++ }, onSetDone = { id, done -> db.setCompletedSets(id, done); refresh++ }, onExerciseUpdate = { id, name, sets, reps, weight -> db.updateExercise(id, name, sets, reps, weight, musclesFor(name)); refresh++ }, onExerciseDelete = { id -> db.deleteExercise(id); refresh++ })
                    3 -> MusclePage(entries, workouts)
                    4 -> StatsPage(workouts, entries)
                    else -> ProfilePage(workouts.size, onCoach = { showCoach = true }, onExport = { exportLauncher.launch("forge-backup-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())}.json") }, onImport = { importLauncher.launch(arrayOf("application/json", "text/*")) })
                }
            }
        }
        if (showCoach) CoachDialog(workouts, entries, onDismiss = { showCoach = false }, onCreatePlan = { goal, equipment ->
            val names = when {
                equipment == "Без оборудования" && goal == "Выносливость" -> listOf("Приседания", "Отжимания", "Планка", "Скручивания", "Подъёмы коленей")
                equipment == "Без оборудования" -> listOf("Приседания", "Отжимания", "Обратные отжимания", "Ягодичный мост", "Планка")
                goal == "Выносливость" -> listOf("Приседания", "Отжимания", "Тяга гантели в наклоне", "Подъёмы на носки", "Планка")
                goal == "Общая форма" -> listOf("Приседания", "Отжимания", "Подтягивания", "Жим гантелей лёжа", "Планка")
                else -> listOf("Приседания", "Подтягивания", "Жим гантелей лёжа", "Тяга гантели в наклоне", "Планка")
            }
            pendingPlan = "План: $goal" to names
            showCoach = false
            showWorkout = true
        })
        pendingImport?.let { backup ->
            AlertDialog(
                onDismissRequest = { pendingImport = null }, containerColor = Panel,
                title = { Text("Заменить текущие данные?") },
                text = { Text("Импорт заменит все текущие тренировки и отметки пропусков. Сначала сохрани резервную копию, если хочешь оставить старые записи.") },
                confirmButton = { TextButton(onClick = {
                    try { val n = db.importJson(backup); refresh++; Toast.makeText(context, "Импортировано тренировок: $n", Toast.LENGTH_LONG).show() }
                    catch (e: Exception) { Toast.makeText(context, "Ошибка импорта: ${e.message}", Toast.LENGTH_LONG).show() }
                    pendingImport = null
                }) { Text("Заменить данные", color = Red) } },
                dismissButton = { TextButton(onClick = { pendingImport = null }) { Text("Отмена") } }
            )
        }
        if (showWorkout) WorkoutDialog(
            initialPlan = pendingPlan,
            onDismiss = { showWorkout = false; pendingPlan = null },
            onSave = { title, duration, list ->
                db.saveWorkout(title, duration, list)
                refresh++
                showWorkout = false
                pendingPlan = null
            }
        )
    }
}



@Composable
private fun StatsPage(workouts: List<Workout>, entries: List<ExerciseEntry>) {
    val totalVolume = workouts.sumOf { it.volume }
    val totalMinutes = workouts.sumOf { it.duration }
    val activeDays = workouts.map { it.date }.distinct().size
    val weekly = (6 downTo 0).map { offset ->
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }.time)
        date to workouts.filter { it.date == date }.sumOf { it.volume }
    }
    val maxVolume = (weekly.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(1.0)
    ScreenColumn {
        PageHeader("Статистика", "Только по сохранённым тренировкам")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Тренировки", workouts.size.toString(), Modifier.weight(1f))
            StatCard("Минуты", totalMinutes.toString(), Modifier.weight(1f))
            StatCard("Дни", activeDays.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Объём за 7 дней", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Выполненные подходы × повторения × вес", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(18.dp))
                Canvas(Modifier.fillMaxWidth().height(130.dp)) {
                    val gap = size.width / (weekly.size * 2f - 1f)
                    weekly.forEachIndexed { i, item ->
                        val h = (item.second / maxVolume * (size.height - 22f)).toFloat()
                        val x = i * gap * 2f
                        drawLine(Outline, Offset(x + gap / 2f, 0f), Offset(x + gap / 2f, size.height), strokeWidth = 1f)
                        drawRoundRect(
                            color = if (item.second > 0) Mint else Panel2,
                            topLeft = Offset(x, size.height - h),
                            size = Size(gap, h.coerceAtLeast(3f)),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("6 дней назад", color = Muted, fontSize = 10.sp)
                    Text("Сегодня", color = Muted, fontSize = 10.sp)
                }
                Spacer(Modifier.height(14.dp))
                Text("Общий выполненный объём", color = Muted, fontSize = 12.sp)
                Text("%.0f кг·повторений".format(Locale.US, totalVolume), fontSize = 22.sp, color = Mint, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Частые упражнения", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                val frequent = entries.groupBy { it.name }.entries.sortedByDescending { it.value.size }.take(5)
                if (frequent.isEmpty()) Text("Добавь тренировки, чтобы появилась статистика.", color = Muted, modifier = Modifier.padding(top = 8.dp))
                frequent.forEach { (name, rows) ->
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.Medium)
                            val best = rows.maxWithOrNull(compareBy<ExerciseEntry> { it.weight }.thenBy { it.reps })!!
                            Text("${rows.size} записей · лучший вес ${best.weight} кг × ${best.reps}", color = Muted, fontSize = 11.sp)
                            Text(if (best.completedSets >= best.sets && best.reps >= 8 && best.weight > 0) "Возможный следующий шаг: + минимальный шаг веса, если техника стабильна" else "Сначала уверенно выполни все запланированные подходы", color = Mint, fontSize = 10.sp)
                        }
                        Text("${rows.maxOf { it.reps }} повт.", color = Mint, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Нагрузка по мышцам", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                val volumes = mutableMapOf<String, Double>()
                entries.forEach { e ->
                    val value = e.completedSets.coerceIn(0, e.sets) * e.reps * e.weight
                    e.muscles.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { m -> volumes[m] = (volumes[m] ?: 0.0) + value }
                }
                val maxMuscleVolume = (volumes.values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
                if (volumes.isEmpty()) Text("Добавь упражнения и отметь выполненные подходы.", color = Muted, fontSize = 12.sp)
                volumes.entries.sortedByDescending { it.value }.take(8).forEach { (muscle, volume) ->
                    Spacer(Modifier.height(9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(muscle, Modifier.width(112.dp), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Box(Modifier.weight(1f).height(7.dp).background(Panel2, CircleShape)) {
                            Box(Modifier.fillMaxWidth((volume / maxMuscleVolume).toFloat().coerceIn(0f, 1f)).height(7.dp).background(Mint, CircleShape))
                        }
                        Text(" ${volume.toInt()}", color = Muted, fontSize = 10.sp)
                    }
                }
                Text("Показан объём по отмеченным выполненным подходам; это приблизительная оценка, а не точная физиологическая нагрузка.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("FORGE", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
            Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Muted)
        }
        Spacer(Modifier.height(18.dp))
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.SemiBold, color = TextMain)
        if (subtitle != null) { Spacer(Modifier.height(4.dp)); Text(subtitle, fontSize = 13.sp, color = Muted) }
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp), content = content)
}

@Composable
private fun HomePage(today: String, workouts: List<Workout>, entries: List<ExerciseEntry>, onStart: () -> Unit, onNavigate: (Int) -> Unit) {
    ScreenColumn {
        PageHeader("Сегодня", today.replaceFirstChar { it.uppercase(Locale("ru")) })
        val latest = workouts.firstOrNull()
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text(if (latest == null) "Точка старта" else "Последняя тренировка", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(if (latest == null) "Создай первую запись" else latest.title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text(if (latest == null) "Планируй нагрузку и следи за прогрессом." else "${latest.duration} мин · ${"%.0f".format(latest.volume)} кг общего объёма", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Начать тренировку", fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Тренировок", workouts.size.toString(), Modifier.weight(1f))
            StatCard("Упражнений", entries.size.toString(), Modifier.weight(1f))
            StatCard("За неделю", workouts.count { it.date >= weekStart() }.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Быстрый доступ", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Открыть", color = Mint, fontSize = 13.sp, modifier = Modifier.clickable { onNavigate(1) })
        }
        Spacer(Modifier.height(10.dp))
        QuickRow("Календарь тренировок", "История по дням", Icons.Default.CalendarMonth) { onNavigate(1) }
        QuickRow("Карта мышц", "Нагрузка по группам", Icons.Default.FitnessCenter) { onNavigate(3) }
        QuickRow("Дневник", "Подходы и результаты", Icons.Default.MenuBook) { onNavigate(2) }
        Spacer(Modifier.height(18.dp))
        Text("Данные появятся здесь по мере тренировок. FORGE не заполняет историю автоматически.", color = Muted, fontSize = 12.sp)
    }
}

private fun weekStart(): String {
    val c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
    return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(7.dp)); Text(value, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun QuickRow(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Panel2, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Mint) }
        Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, fontWeight = FontWeight.Medium); Text(detail, color = Muted, fontSize = 12.sp) }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun CalendarPage(workouts: List<Workout>, missed: Set<String>, onToggleMissed: (String) -> Unit) {
    var year by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    var view by remember { mutableStateOf("Год") }
    var selectedDate by remember { mutableStateOf<String?>(null) }
    val doneDates = workouts.map { it.date }.toSet()
    ScreenColumn {
        PageHeader("Календарь тренировок")
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(4.dp)) {
            listOf("Год", "Месяц", "Неделя").forEach { v ->
                Box(Modifier.weight(1f).background(if (view == v) Mint else Color.Transparent, RoundedCornerShape(12.dp)).clickable { view = v }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(v, color = if (view == v) Color(0xFF062319) else Muted, fontSize = 13.sp, fontWeight = if (view == v) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { year-- }) { Icon(Icons.Default.ChevronLeft, null, tint = Muted) }
            Text(if (view == "Год") "$year" else "$view · $year", fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { year++ }) { Icon(Icons.Default.ChevronRight, null, tint = Muted) }
        }
        Text(if (view == "Год") "Активность за год" else "Активность · $view", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            LegendDot(Mint, "Тренировка"); LegendDot(Outline, "Нет записи"); LegendDot(Red, "Пропуск")
        }
        Spacer(Modifier.height(18.dp))
        if (view == "Год") {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                (0..11).forEach { month ->
                    Column(Modifier.width(31.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(listOf("Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек")[month], fontSize = 9.sp, color = Muted)
                        Spacer(Modifier.height(8.dp))
                        val cal = Calendar.getInstance().apply { set(year, month, 1) }
                        val count = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            (1..count).forEach { day ->
                                val date = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                val color = when { date in doneDates -> Mint; date in missed -> Red; else -> Panel2 }
                                Box(Modifier.size(10.dp).background(color, RoundedCornerShape(2.dp)).combinedClickable(onClick = { selectedDate = date }, onLongClick = { selectedDate = date; onToggleMissed(date) }))
                            }
                        }
                    }
                }
            }
        } else if (view == "Месяц") {
            var month by remember(year) { mutableIntStateOf(Calendar.getInstance().get(Calendar.MONTH)) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { month = (month + 11) % 12 }) { Icon(Icons.Default.ChevronLeft, null, tint = Muted) }
                Text(listOf("Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь")[month], fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { month = (month + 1) % 12 }) { Icon(Icons.Default.ChevronRight, null, tint = Muted) }
            }
            val monthCal = Calendar.getInstance().apply { set(year, month, 1) }
            val offset = (monthCal.get(Calendar.DAY_OF_WEEK) - monthCal.firstDayOfWeek + 7) % 7
            val days = monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val cells = List(offset) { 0 } + (1..days).toList()
            val weekdayLabels = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { weekdayLabels.forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Muted, fontSize = 11.sp) } }
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (week + List(7-week.size) { 0 }).forEach { day ->
                        Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).then(if (day == 0) Modifier else Modifier.background(when { String.format(Locale.US, "%04d-%02d-%02d", year, month+1, day) in doneDates -> Mint; String.format(Locale.US, "%04d-%02d-%02d", year, month+1, day) in missed -> Red; else -> Panel2 }, RoundedCornerShape(7.dp)).clickable { selectedDate = String.format(Locale.US, "%04d-%02d-%02d", year, month+1, day) }), contentAlignment = Alignment.Center) { if (day != 0) Text(day.toString(), fontSize = 12.sp, color = if (String.format(Locale.US, "%04d-%02d-%02d", year, month+1, day) in doneDates) Bg else TextMain) }
                    }
                }
            }
        } else {
            val weekDays = (6 downTo 0).map { offset -> Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }.time }
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                weekDays.forEach { dateObj ->
                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(dateObj)
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).clickable { selectedDate = date }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(when { date in doneDates -> Mint; date in missed -> Red; else -> Panel2 }, CircleShape))
                        Text(SimpleDateFormat("EEE, d MMM", Locale("ru")).format(dateObj), Modifier.weight(1f).padding(start = 10.dp), fontSize = 13.sp)
                        Text(if (date in doneDates) "Тренировка" else if (date in missed) "Пропуск" else "—", color = if (date in doneDates) Mint else Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("Завершено", color = Muted, fontSize = 12.sp); Text(workouts.size.toString(), fontSize = 24.sp, fontWeight = FontWeight.SemiBold) }
            Column { Text("Общий объём", color = Muted, fontSize = 12.sp); Text("${workouts.sumOf { it.volume }.toInt()} кг", fontSize = 24.sp, fontWeight = FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(18.dp))
        selectedDate?.let { date ->
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text(date, fontWeight = FontWeight.SemiBold)
                    val matches = workouts.filter { it.date == date }
                    Text(if (matches.isEmpty()) if (date in missed) "Отмечено как пропуск" else "Нет сохранённых тренировок" else matches.joinToString { it.title }, color = if (date in missed) Red else Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Удерживай день в календаре, чтобы отметить/снять пропуск.", color = Muted, fontSize = 10.sp)
                    if (matches.isNotEmpty()) Text("Тренировка выполнена — пропуск недоступен.", color = Muted, fontSize = 10.sp)
                    else TextButton(onClick = { onToggleMissed(date) }) { Text(if (date in missed) "Снять отметку пропуска" else "Отметить пропуск", color = if (date in missed) Muted else Red) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Листай календарь по горизонтали, чтобы увидеть все месяцы.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(9.dp).background(color, RoundedCornerShape(2.dp)))
        Text(label, fontSize = 10.sp, color = Muted)
    }
}

@Composable
private fun DiaryPage(workouts: List<Workout>, entries: List<ExerciseEntry>, onStart: () -> Unit, onDelete: (Long) -> Unit, onUpdate: (Long, String, Int) -> Unit, onSetDone: (Long, Int) -> Unit, onExerciseUpdate: (Long, String, Int, Int, Double) -> Unit, onExerciseDelete: (Long) -> Unit) {
    var editing by remember { mutableStateOf<Workout?>(null) }
    var editingExercise by remember { mutableStateOf<ExerciseEntry?>(null) }
    var deletingWorkout by remember { mutableStateOf<Workout?>(null) }
    ScreenColumn {
        PageHeader("Дневник тренировок", "Все записи сохраняются на устройстве")
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Новая тренировка")
        }
        Spacer(Modifier.height(16.dp))
        if (workouts.isEmpty()) {
            EmptyState("Пока нет тренировок", "Создай первую запись — она появится в календаре.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(workouts, key = { it.id }) { w ->
                    Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(w.title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp); Text(w.date, color = Muted, fontSize = 12.sp) }
                                Text("${w.duration} мин", color = Mint, fontSize = 12.sp)
                                IconButton(onClick = { editing = w }) { Icon(Icons.Default.Edit, contentDescription = "Изменить тренировку", tint = Mint) }
                                IconButton(onClick = { deletingWorkout = w }) { Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить тренировку", tint = Red) }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("${entries.count { it.workoutId == w.id }} упражн. · ${w.volume.toInt()} кг·повторений выполнено", color = Muted, fontSize = 12.sp)
                            entries.filter { it.workoutId == w.id }.forEach { e ->
                                Row(Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${e.name}: ${e.sets} × ${e.reps} · ${e.weight} кг", fontSize = 12.sp, color = TextMain)
                                        Text("Подходы выполнены: ${e.completedSets}/${e.sets}", fontSize = 10.sp, color = if (e.completedSets >= e.sets) Mint else Muted)
                                    }
                                    IconButton(onClick = { editingExercise = e }) { Icon(Icons.Default.Edit, contentDescription = "Редактировать упражнение", tint = Mint) }
                                    TextButton(onClick = { if (e.completedSets < e.sets) onSetDone(e.id, e.completedSets + 1) else onSetDone(e.id, 0) }) {
                                        Text(if (e.completedSets < e.sets) "+ подход" else "Сброс", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    editing?.let { workout ->
        var title by remember(workout.id) { mutableStateOf(workout.title) }
        var duration by remember(workout.id) { mutableStateOf(workout.duration.toString()) }
        AlertDialog(onDismissRequest = { editing = null }, containerColor = Panel,
            title = { Text("Изменить тренировку") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(3) }, label = { Text("Длительность, мин") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = { onUpdate(workout.id, title.ifBlank { "Тренировка" }, duration.toIntOrNull()?.coerceAtLeast(1) ?: workout.duration); editing = null }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Отмена") } })
    }
    editingExercise?.let { exercise ->
        var name by remember(exercise.id) { mutableStateOf(exercise.name) }
        var sets by remember(exercise.id) { mutableStateOf(exercise.sets.toString()) }
        var reps by remember(exercise.id) { mutableStateOf(exercise.reps.toString()) }
        var weight by remember(exercise.id) { mutableStateOf(exercise.weight.toString()) }
        AlertDialog(onDismissRequest = { editingExercise = null }, containerColor = Panel,
            title = { Text("Редактировать упражнение") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(sets, { sets = it.filter(Char::isDigit).take(2) }, label = { Text("Подходы") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(reps, { reps = it.filter(Char::isDigit).take(3) }, label = { Text("Повторы") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(weight, { weight = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.') }, label = { Text("Кг") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                TextButton(onClick = { onExerciseDelete(exercise.id); editingExercise = null }) { Text("Удалить упражнение", color = Red) }
            } },
            confirmButton = { TextButton(onClick = { onExerciseUpdate(exercise.id, name.ifBlank { exercise.name }, sets.toIntOrNull()?.coerceAtLeast(1) ?: exercise.sets, reps.toIntOrNull()?.coerceAtLeast(1) ?: exercise.reps, weight.toDoubleOrNull()?.coerceAtLeast(0.0) ?: exercise.weight); editingExercise = null }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { editingExercise = null }) { Text("Отмена") } })
    }
    deletingWorkout?.let { workout ->
        AlertDialog(onDismissRequest = { deletingWorkout = null }, containerColor = Panel,
            title = { Text("Удалить тренировку?") },
            text = { Text("Запись «${workout.title}» и её упражнения будут удалены без возможности восстановления.") },
            confirmButton = { TextButton(onClick = { onDelete(workout.id); deletingWorkout = null }) { Text("Удалить", color = Red) } },
            dismissButton = { TextButton(onClick = { deletingWorkout = null }) { Text("Отмена") } })
    }
}

@Composable
private fun MusclePage(entries: List<ExerciseEntry>, workouts: List<Workout>) {
    var back by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Грудь") }
    val cutoff = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -6) }.time)
    val recentWorkoutIds = workouts.filter { it.date >= cutoff }.map { it.id }.toSet()
    val recentEntries = entries.filter { it.workoutId in recentWorkoutIds }
    val trained = recentEntries.flatMap { it.muscles.split(",") }.map { it.trim() }.toSet()
    val related = recentEntries.filter { selected in it.muscles.split(",").map(String::trim) }
    val weeklyVolume = related.sumOf { it.completedSets.coerceIn(0, it.sets) * it.reps * it.weight }
    val weeklySets = related.sumOf { it.completedSets.coerceIn(0, it.sets) }
    ScreenColumn {
        PageHeader("Карта мышц", "Нагрузка за последние 7 дней")
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(4.dp)) {
            listOf("Вид спереди", "Вид сзади").forEachIndexed { i, label ->
                Box(Modifier.weight(1f).background(if (back == (i == 1)) Mint else Color.Transparent, RoundedCornerShape(12.dp)).clickable { back = i == 1 }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(label, fontSize = 12.sp, color = if (back == (i == 1)) Color(0xFF062319) else Muted)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        MuscleIllustration(back, selected, trained) { selected = it }
        Text("Выбери группу мышц на схеме или ниже", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            muscleNames.forEach { m ->
                FilterChip(selected = selected == m, onClick = { selected = m }, label = { Text(m, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Mint, selectedLabelColor = Color(0xFF062319)))
            }
        }
        Spacer(Modifier.height(14.dp))
        Surface(color = Panel, shape = RoundedCornerShape(17.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text(selected, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Row {
                    Column(Modifier.weight(1f)) { Text("Последняя запись", color = Muted, fontSize = 10.sp); Text(if (related.isEmpty()) "Нет данных" else "${related.size} упражн.", fontSize = 13.sp) }
                    Column(Modifier.weight(1f)) { Text("Объём записей", color = Muted, fontSize = 10.sp); Text("${weeklyVolume.toInt()} кг·повт.", fontSize = 13.sp) }
                    Column(Modifier.weight(1f)) { Text("Восстановление", color = Muted, fontSize = 10.sp); Text(if (related.isEmpty()) "—" else "≈ 1–2 дня", fontSize = 13.sp) }
                }
                Spacer(Modifier.height(12.dp))
                val progress by animateFloatAsState(if (related.isEmpty()) 0f else (weeklyVolume / 10000.0).toFloat().coerceIn(0.12f, 1f), label = "workload")
                Box(Modifier.fillMaxWidth().height(6.dp).background(Panel2, CircleShape)) {
                    Box(Modifier.fillMaxWidth(progress).height(6.dp).background(Mint, CircleShape))
                }
                Spacer(Modifier.height(8.dp))
                Text("Восстановление — приблизительная оценка, не медицинский показатель.", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun MuscleIllustration(back: Boolean, selected: String, trained: Set<String>, onSelect: (String) -> Unit) {
    val regions = if (!back) listOf("Плечи","Грудь","Бицепс","Предплечья","Пресс","Косые мышцы","Квадрицепсы","Икры")
        else listOf("Плечи","Спина","Широчайшие","Трицепс","Предплечья","Ягодицы","Бицепс бедра","Икры")
    Canvas(Modifier.fillMaxWidth().height(320.dp).pointerInput(back) {
        detectTapGestures { offset ->
            val x = offset.x / size.width * 360f
            val y = offset.y / size.height * 320f
            // Hit regions follow the visible muscle shapes; more specific regions are checked first.
            val target = when {
                !back && y in 68f..95f && x in 145f..215f -> "Грудь"
                !back && y in 98f..144f && x in 158f..202f -> "Пресс"
                !back && y in 99f..140f && (x in 137f..154f || x in 206f..223f) -> "Косые мышцы"
                back && y in 60f..104f && x in 153f..207f -> "Спина"
                back && y in 86f..138f && (x in 137f..161f || x in 199f..223f) -> "Широчайшие"
                back && y in 145f..179f && x in 151f..209f -> "Ягодицы"
                y in 88f..119f && (x in 112f..130f || x in 230f..248f) -> if (back) "Трицепс" else "Бицепс"
                y in 122f..170f && (x in 100f..116f || x in 244f..260f) -> "Предплечья"
                y in 184f..247f && x in 143f..217f -> if (back) "Бицепс бедра" else "Квадрицепсы"
                y in 251f..300f && (x in 146f..167f || x in 193f..214f) -> "Икры"
                y in 58f..85f && (x in 124f..155f || x in 205f..236f) -> "Плечи"
                else -> selected
            }
            onSelect(target)
        }
    }) {
        val sx = size.width / 360f
        val sy = size.height / 320f
        fun p(x: Float, y: Float) = Offset(x * sx, y * sy)
        fun muscle(name: String, x: Float, y: Float, w: Float, h: Float, round: Float = 12f) {
            val c = if (name == selected || name in trained) Mint else Color(0xFF667174)
            drawRoundRect(c, p(x,y), Size(w*sx,h*sy), androidx.compose.ui.geometry.CornerRadius(round*sx, round*sx))
            drawRoundRect(Color(0xFF101719), p(x,y), Size(w*sx,h*sy), androidx.compose.ui.geometry.CornerRadius(round*sx,round*sx), style=Stroke(1.3f*sx))
        }
        val skin = Color(0xFF9DA8AA)
        // Head, neck, torso and limbs: deliberately lightweight vector illustration.
        drawCircle(skin, 18*sx, p(180f,24f))
        drawRoundRect(skin, p(169f,42f), Size(22*sx,20*sy), androidx.compose.ui.geometry.CornerRadius(5*sx))
        drawRoundRect(skin, p(132f,58f), Size(96*sx,92*sy), androidx.compose.ui.geometry.CornerRadius(25*sx))
        drawRoundRect(skin, p(145f,144f), Size(70*sx,45*sy), androidx.compose.ui.geometry.CornerRadius(13*sx))
        // arms and forearms
        drawRoundRect(skin, p(112f,66f), Size(21*sx,63*sy), androidx.compose.ui.geometry.CornerRadius(10*sx))
        drawRoundRect(skin, p(100f,120f), Size(17*sx,55*sy), androidx.compose.ui.geometry.CornerRadius(8*sx))
        drawRoundRect(skin, p(227f,66f), Size(21*sx,63*sy), androidx.compose.ui.geometry.CornerRadius(10*sx))
        drawRoundRect(skin, p(243f,120f), Size(17*sx,55*sy), androidx.compose.ui.geometry.CornerRadius(8*sx))
        // legs
        drawRoundRect(skin, p(143f,182f), Size(29*sx,69*sy), androidx.compose.ui.geometry.CornerRadius(13*sx))
        drawRoundRect(skin, p(188f,182f), Size(29*sx,69*sy), androidx.compose.ui.geometry.CornerRadius(13*sx))
        drawRoundRect(skin, p(146f,247f), Size(22*sx,58*sy), androidx.compose.ui.geometry.CornerRadius(10*sx))
        drawRoundRect(skin, p(192f,247f), Size(22*sx,58*sy), androidx.compose.ui.geometry.CornerRadius(10*sx))
        if (!back) {
            muscle("Плечи",124f,58f,31f,27f); muscle("Плечи",205f,58f,31f,27f)
            muscle("Грудь",148f,68f,30f,27f); muscle("Грудь",182f,68f,30f,27f)
            muscle("Бицепс",112f,88f,18f,31f); muscle("Бицепс",230f,88f,18f,31f)
            muscle("Предплечья",100f,122f,16f,48f); muscle("Предплечья",244f,122f,16f,48f)
            muscle("Пресс",158f,98f,44f,46f,7f)
            muscle("Косые мышцы",139f,100f,15f,39f); muscle("Косые мышцы",206f,100f,15f,39f)
            muscle("Квадрицепсы",143f,184f,29f,62f); muscle("Квадрицепсы",188f,184f,29f,62f)
            muscle("Икры",146f,251f,21f,48f); muscle("Икры",193f,251f,21f,48f)
        } else {
            muscle("Плечи",124f,58f,31f,27f); muscle("Плечи",205f,58f,31f,27f)
            muscle("Спина",153f,60f,54f,44f,10f)
            muscle("Широчайшие",137f,86f,24f,52f); muscle("Широчайшие",199f,86f,24f,52f)
            muscle("Трицепс",112f,88f,18f,31f); muscle("Трицепс",230f,88f,18f,31f)
            muscle("Предплечья",100f,122f,16f,48f); muscle("Предплечья",244f,122f,16f,48f)
            muscle("Ягодицы",151f,145f,27f,35f); muscle("Ягодицы",182f,145f,27f,35f)
            muscle("Бицепс бедра",143f,184f,29f,62f); muscle("Бицепс бедра",188f,184f,29f,62f)
            muscle("Икры",146f,251f,21f,48f); muscle("Икры",193f,251f,21f,48f)
        }
        drawLine(Color(0xFF263336), p(180f,48f), p(180f,305f), 1f*sx)
    }
}

@Composable
private fun ProfilePage(count: Int, onCoach: () -> Unit, onExport: () -> Unit, onImport: () -> Unit) {
    ScreenColumn {
        PageHeader("Профиль", "Настройки и данные")
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Outline)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("FORGE", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Локальный профиль", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp)); Text("Сохранено тренировок: $count")
                Spacer(Modifier.height(8.dp)); Text("Данные хранятся на этом устройстве в локальной базе SQLite.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onCoach, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Открыть AI Coach") }
                OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Экспорт резервной копии JSON") }
                OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Импорт резервной копии JSON") }
                Text("Импорт заменяет текущие данные. Перед импортом сначала сделай экспорт.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun CoachDialog(workouts: List<Workout>, entries: List<ExerciseEntry>, onDismiss: () -> Unit, onCreatePlan: (String, String) -> Unit) {
    var goal by remember { mutableStateOf("Сила") }
    var equipment by remember { mutableStateOf("Гантели + турник") }
    var daysPerWeek by remember { mutableIntStateOf(3) }
    val recent = workouts.filter { it.date >= SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -7) }.time) }
    val recentEntries = entries.filter { e -> recent.any { it.id == e.workoutId } }
    val trained = recentEntries.flatMap { it.muscles.split(",") }.map { it.trim() }.toSet()
    val allMuscles = listOf("Грудь", "Спина", "Ноги", "Плечи", "Руки", "Пресс")
    val missing = allMuscles.filter { m -> when(m) { "Ноги" -> trained.none { it in listOf("Квадрицепсы", "Ягодицы", "Бицепс бедра", "Икры") }; "Руки" -> trained.none { it in listOf("Бицепс", "Трицепс") }; else -> trained.none { it.contains(m, ignoreCase = true) } } }
    val advice = when {
        workouts.isEmpty() -> "Начни с короткой записи: 3–5 упражнений, без попытки сделать всё сразу. Записывай подходы и повторения — так появится база для персональных выводов."
        recent.size >= 6 -> "За 7 дней записано много тренировок (${recent.size}). Запланируй отдых или лёгкий день, если чувствуешь усталость. Прогресс зависит и от восстановления."
        recent.isEmpty() -> "За последние 7 дней нет записей. Вернись постепенно: выбери знакомую тренировку и оставь запас сил, не пытайся компенсировать пропущенное."
        missing.isNotEmpty() -> "В записях за неделю мало данных по направлениям: ${missing.joinToString()}. Если они входят в твою программу, добавь их в следующие тренировки равномерно, без резкого увеличения объёма."
        else -> "Неделя выглядит разнообразно по отмеченным мышцам. Сравни повторы и рабочий вес с прошлой неделей; увеличивай нагрузку постепенно и только при хорошей технике."
    }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel,
        title = { Text("AI Coach", color = TextMain) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 520.dp)) {
            Text("Разбор по твоему дневнику", color = Mint, fontWeight = FontWeight.SemiBold)
            Text(advice, color = TextMain)
            Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) { Column(Modifier.padding(12.dp)) {
                Text("За 7 дней", color = Muted, fontSize = 12.sp)
                Text("${recent.size} тренировок · ${recentEntries.size} упражнений", fontWeight = FontWeight.SemiBold)
                Text("Учтённые мышцы: ${if (trained.isEmpty()) "пока нет" else trained.joinToString()}", color = Muted, fontSize = 11.sp)
            } }
            Divider(color = Outline)
            Text("Собрать план", color = Mint, fontWeight = FontWeight.SemiBold)
            Text("Цель", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("Сила", "Выносливость", "Общая форма").forEach { option ->
                    FilterChip(selected = goal == option, onClick = { goal = option }, label = { Text(option, fontSize = 10.sp) })
                }
            }
            Text("Оборудование", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("Без оборудования", "Гантели + турник").forEach { option ->
                    FilterChip(selected = equipment == option, onClick = { equipment = option }, label = { Text(option, fontSize = 10.sp) })
                }
            }
            Text("Тренировок в неделю: $daysPerWeek", color = Muted, fontSize = 12.sp)
            Slider(value = daysPerWeek.toFloat(), onValueChange = { daysPerWeek = it.toInt().coerceIn(2, 5) }, valueRange = 2f..5f, steps = 2)
            val plan = when {
                goal == "Выносливость" -> listOf("Лёгкая круговая тренировка: приседания, отжимания, планка", "Техника и умеренное кардио", "Круговая тренировка всего тела")
                goal == "Общая форма" -> listOf("Всё тело: приседания, отжимания, тяга", "Верх тела и корпус", "Ноги, спина и лёгкая работа на выносливость")
                else -> listOf("Всё тело: базовые движения, без отказа", "Верх тела: тяги и жимовые движения", "Ноги и корпус: приседания, наклоны, стабилизация")
            }
            Text("Пример структуры на неделю", fontWeight = FontWeight.SemiBold)
            repeat(daysPerWeek) { index ->
                Text("${index + 1}. ${plan[index % plan.size]}", fontSize = 12.sp)
            }
            Text(if (equipment == "Без оборудования") "План будет собран из упражнений с собственным весом." else "План использует гантели и турник там, где это подходит; выполняй упражнения с контролем техники.", color = Muted, fontSize = 11.sp)
            Button(onClick = { onCreatePlan(goal, equipment) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Создать тренировку по этому плану")
            }
            Text("Это локальный генератор по правилам, не облачная нейросеть. План — черновик: учитывай самочувствие, восстановление и тренировки по боксу.", color = Muted, fontSize = 11.sp)
        } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } })
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.FitnessCenter, null, tint = Mint, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(12.dp)); Text(title, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp)); Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun WorkoutDialog(initialPlan: Pair<String, List<String>>?, onDismiss: () -> Unit, onSave: (String, Int, List<ExerciseEntry>) -> Unit) {
    var title by remember(initialPlan) { mutableStateOf(initialPlan?.first ?: "Тренировка") }
    var duration by remember { mutableStateOf("45") }
    var exerciseName by remember { mutableStateOf("Отжимания") }
    var sets by remember { mutableStateOf("3") }
    var reps by remember { mutableStateOf("10") }
    var weight by remember { mutableStateOf("0") }
    var exerciseList by remember(initialPlan) {
        mutableStateOf(initialPlan?.second.orEmpty().mapNotNull { name ->
            exerciseLibrary.find { it.name == name }?.let { preset -> ExerciseEntry(0, 0, preset.name, preset.sets, preset.reps, preset.weight, preset.muscles) }
        })
    }
    var libraryFilter by remember { mutableStateOf("") }
    var timerSeconds by remember { mutableIntStateOf(0) }
    var timerRunning by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Новая тренировка", color = TextMain) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.heightIn(max = 500.dp)) {
                item { OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true) }
                item { OutlinedTextField(duration, { duration = it.filter(Char::isDigit).take(3) }, label = { Text("Длительность, мин") }, singleLine = true) }
                item { Divider(color = Outline); Text("Шаблоны тренировки", fontWeight = FontWeight.SemiBold) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        workoutTemplates.keys.chunked(2).forEach { rowTemplates ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                rowTemplates.forEach { template ->
                                    OutlinedButton(onClick = {
                                        title = template
                                        exerciseList = workoutTemplates[template].orEmpty().mapNotNull { n -> exerciseLibrary.find { it.name == n }?.let { preset -> ExerciseEntry(0, 0, preset.name, preset.sets, preset.reps, preset.weight, preset.muscles) } }
                                    }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp)) { Text(template, fontSize = 10.sp, maxLines = 2) }
                                }
                            }
                        }
                    }
                }
                item { Divider(color = Outline); Text("Библиотека упражнений", fontWeight = FontWeight.SemiBold) }
                item { OutlinedTextField(libraryFilter, { libraryFilter = it; exerciseName = it }, label = { Text("Поиск упражнения") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        exerciseLibrary.filter { libraryFilter.isBlank() || it.name.contains(libraryFilter, ignoreCase = true) }.take(7).forEach { preset ->
                            Row(Modifier.fillMaxWidth().clickable {
                                exerciseName = preset.name; sets = preset.sets.toString(); reps = preset.reps.toString(); weight = preset.weight.toString()
                            }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(preset.name, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                    Text(preset.muscles.replace(",", " · "), fontSize = 10.sp, color = Muted)
                                }
                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Выбрать ${preset.name}", tint = Mint, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
                item { OutlinedTextField(exerciseName, { exerciseName = it }, label = { Text("Название выбранного упражнения") }, singleLine = true) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(sets, { sets = it.filter(Char::isDigit).take(2) }, label = { Text("Подходы") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(reps, { reps = it.filter(Char::isDigit).take(3) }, label = { Text("Повторы") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(weight, { weight = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.') }, label = { Text("Кг") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                item {
                    OutlinedButton(onClick = {
                        if (exerciseName.isNotBlank()) {
                            val preset = exerciseLibrary.find { it.name.equals(exerciseName.trim(), ignoreCase = true) }
                            exerciseList = exerciseList + ExerciseEntry(0, 0, exerciseName.trim(), sets.toIntOrNull()?.coerceAtLeast(1) ?: 1, reps.toIntOrNull()?.coerceAtLeast(1) ?: 1, weight.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0, preset?.muscles ?: musclesFor(exerciseName))
                            exerciseName = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Добавить упражнение") }
                }
                if (exerciseList.isNotEmpty()) item { Text("Упражнений добавлено: ${exerciseList.size}", color = Mint) }
                items(exerciseList) { e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${e.name} · ${e.sets} × ${e.reps} · ${e.weight} кг", Modifier.weight(1f), fontSize = 12.sp)
                        IconButton(onClick = { exerciseList = exerciseList - e }) { Icon(Icons.Default.Close, null, tint = Red) }
                    }
                }
                item {
                    Divider(color = Outline)
                    Text("Таймер отдыха", fontWeight = FontWeight.SemiBold)
                    Text("${timerSeconds / 60}:${(timerSeconds % 60).toString().padStart(2,'0')}", fontSize = 22.sp, color = Mint)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { timerSeconds = 90; timerRunning = false }) { Text("90 сек") }
                        OutlinedButton(onClick = { timerSeconds = 120; timerRunning = false }) { Text("2 мин") }
                        OutlinedButton(onClick = { timerRunning = !timerRunning }) { Text(if (timerRunning) "Пауза" else "Старт") }
                    }
                    if (timerRunning && timerSeconds > 0) {
                        LaunchedEffect(timerRunning, timerSeconds) {
                            kotlinx.coroutines.delay(1000)
                            if (timerRunning && timerSeconds > 0) timerSeconds--
                            if (timerSeconds == 0) timerRunning = false
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (exerciseList.isNotEmpty()) onSave(title.ifBlank { "Тренировка" }, duration.toIntOrNull()?.coerceAtLeast(1) ?: 45, exerciseList) }, enabled = exerciseList.isNotEmpty()) { Text("Завершить и сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
